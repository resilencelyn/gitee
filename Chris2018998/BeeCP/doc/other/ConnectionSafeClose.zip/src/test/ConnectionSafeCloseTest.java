package test;/*
 * Copyright Chris2018998
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import cn.beecp.BeeDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

import com.alibaba.druid.pool.DruidDataSource;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.zaxxer.hikari.HikariDataSource;
import org.vibur.dbcp.ViburDBCPDataSource;
import test.type.BeeCP_C;
import test.type.C3P0;
import test.type.DBCP;
import test.type.DBCP2;
import test.type.Druid;
import test.type.HikariCP;
import test.type.TomcatJDBC;
import test.type.Vibur;

public class ConnectionSafeCloseTest {
    public static void main(String[]args)throws Exception{
        DataSourceConfig.loadConfig();

        ComboPooledDataSource C3P0Dataource =null;
        try {
            C3P0Dataource = C3P0.createDataSource();
            test(C3P0Dataource,"C3P0" );
        }catch (Exception e){
        }finally {
            if(C3P0Dataource!=null) C3P0Dataource.close();
        }

        org.apache.commons.dbcp.BasicDataSource DBCPDataource =null;
        try {
          DBCPDataource = DBCP.createDataSource();
          test(DBCPDataource,"DBCP" );
        }catch (Exception e){
        }finally {
            try{ if(DBCPDataource!=null) DBCPDataource.close();}catch (Exception e){}
        }

        org.apache.commons.dbcp2.BasicDataSource DBCP2Dataource =null;
        try {
              DBCP2Dataource = DBCP2.createDataSource();
            test(DBCP2Dataource,"DBCP2" );
        }catch (Exception e){
        }finally {
            try{ if(DBCP2Dataource!=null) DBCP2Dataource.close();}catch (Exception e){}
        }

        org.apache.tomcat.jdbc.pool.DataSource TomcatDataource=null;
        try {
            TomcatDataource = TomcatJDBC.createDataSource();
            test(TomcatDataource,"Tomcat" );
        }catch (Exception e){
        }finally {
            try{if(TomcatDataource!=null) TomcatDataource.close();}catch (Exception e){}
        }

        ViburDBCPDataSource ViburDataource = null;
        try {
            ViburDataource = Vibur.createDataSource();
            test(ViburDataource,"Vibur" );
        }catch (Exception e){
        }finally {
            try{if(ViburDataource!=null)ViburDataource.close();}catch (Exception e){}
        }

        DruidDataSource DruidDataource =null;
        try {
            DruidDataource = Druid.createDataSource();
            test(DruidDataource,"Druid" );
        }catch (Exception e){
        }finally {
            try{if(DruidDataource!=null)DruidDataource.close();}catch (Exception e){}
        }

        HikariDataSource HikariDataource = null;
        try {
             HikariDataource = HikariCP.createDataSource();
            test(HikariDataource,"Hikari" );
        }catch (Exception e){
        }finally {
            try{ if(HikariDataource!=null) HikariDataource.close();}catch (Exception e){}
        }

        BeeDataSource BeeDataource =null;
        try {
            BeeDataource = BeeCP_C.createDataSource();
            test(BeeDataource,"BeeCP" );
        }catch (Exception e){
        }finally {
            try{if(BeeDataource!=null) BeeDataource.close();}catch (Exception e){}
        }
    }

    public static void test(DataSource ds,String dataSourceName) throws Exception {
        int threadSize=1000;
        Connection con = ds.getConnection();
        long startTime=System.nanoTime()+ TimeUnit.SECONDS.toNanos(10);
        CountDownLatch countDownLatch = new CountDownLatch(threadSize);
        CloseThread[] testThreads=new  CloseThread[threadSize];
        for(int i=0;i<threadSize;i++){
            testThreads[i]=new CloseThread(startTime,con,countDownLatch);
            testThreads[i].start();
        }
        countDownLatch.await();
        int successSize=0,failedSize=0;
        for(int i=0;i<threadSize;i++){
            if(testThreads[i].closedInd) {
                successSize++;
            }else{
                failedSize++;
            }
        }

        if((successSize==1 && failedSize==threadSize-1)){
            System.out.println("DataSource["+dataSourceName+"]connection safe close");
        }else{
            System.err.println("DataSource["+dataSourceName+"]exists connection safe close bug");
        }
    }

    //thread to close connection
    static class CloseThread extends Thread {
        private long startTime;
        private Connection con;
        private CountDownLatch countDownLatch;
        boolean closedInd;

        public CloseThread(long startTime,Connection con,CountDownLatch countDownLatch) {
            this.con = con;
            this.startTime=startTime;
            this.countDownLatch = countDownLatch;
        }
        public void run() {
            try{
                LockSupport.parkNanos(startTime-System.nanoTime());
                con.close();
                closedInd=true;
            }catch(Exception e){
                //e.printStackTrace();
                closedInd=false;
            }
            countDownLatch.countDown();
        }
    }
}