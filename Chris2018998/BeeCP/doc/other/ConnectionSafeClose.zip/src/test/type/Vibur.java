package test.type;

import org.vibur.dbcp.ViburDBCPDataSource;
import test.DataSourceConfig;

import java.util.concurrent.Executors;

public class Vibur {
	public static ViburDBCPDataSource createDataSource()throws Exception {
		ViburDBCPDataSource vibur = new ViburDBCPDataSource();
        vibur.setJdbcUrl( DataSourceConfig.JDBC_URL );
        vibur.setUsername(DataSourceConfig.JDBC_USER);
        vibur.setPassword(DataSourceConfig.JDBC_PASSWORD);
        vibur.setDriverClassName(DataSourceConfig.JDBC_DRIVER);
        vibur.setConnectionTimeoutInMs(DataSourceConfig.REQUEST_TIMEOUT);
        vibur.setValidateTimeoutInSeconds(3);
        vibur.setLoginTimeoutInSeconds(2);

        vibur.setPoolInitialSize(DataSourceConfig.POOL_INIT_SIZE);
        vibur.setPoolMaxSize(DataSourceConfig.POOL_MAX_ACTIVE);
        vibur.setConnectionIdleLimitInSeconds(1);
        vibur.setAcquireRetryAttempts(0);
        vibur.setReducerTimeIntervalInSeconds(0);
        vibur.setUseNetworkTimeout(true);
        vibur.setNetworkTimeoutExecutor(Executors.newFixedThreadPool(1));
        
        vibur.setClearSQLWarnings(true);
        vibur.setResetDefaultsAfterUse(true);
        vibur.setDefaultAutoCommit(false);
		vibur.setPoolFair(false);
        vibur.start();
		return vibur;
	}
}
