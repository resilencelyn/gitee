package test.type;

import java.beans.PropertyVetoException;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import test.DataSourceConfig;

/**
 * CP30
 */
public class C3P0 {
	
	public static ComboPooledDataSource createDataSource()throws Exception {
		ComboPooledDataSource datasource = new ComboPooledDataSource();
		try {
			datasource.setDriverClass(DataSourceConfig.JDBC_DRIVER);
		} catch (PropertyVetoException e1) {
			e1.printStackTrace();
		}
		datasource.setJdbcUrl(DataSourceConfig.JDBC_URL);
		datasource.setUser(DataSourceConfig.JDBC_USER);
		datasource.setPassword(DataSourceConfig.JDBC_PASSWORD);
		datasource.setInitialPoolSize(DataSourceConfig.POOL_INIT_SIZE);
		datasource.setMinPoolSize(DataSourceConfig.POOL_MIN_ACTIVE);
		datasource.setMaxPoolSize(DataSourceConfig.POOL_MAX_ACTIVE);
		datasource.setCheckoutTimeout(DataSourceConfig.REQUEST_TIMEOUT);
		datasource.setMaxStatementsPerConnection(20);
		datasource.setTestConnectionOnCheckin(false);
		datasource.setTestConnectionOnCheckout(true);
		datasource.setAutoCommitOnClose(false);
		datasource.setPreferredTestQuery("select 1 from dual");
	
		return datasource;
	}
}
