package test.type;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import test.DataSourceConfig;

/**
 * 光，very fast 
 */
public class HikariCP {
	public static HikariDataSource createDataSource() throws Exception {
		HikariConfig config = new HikariConfig();
		config.setJdbcUrl(DataSourceConfig.JDBC_URL);
		config.setDriverClassName(DataSourceConfig.JDBC_DRIVER);
		config.setUsername(DataSourceConfig.JDBC_USER);
		config.setPassword(DataSourceConfig.JDBC_PASSWORD);
		config.setMinimumIdle(DataSourceConfig.POOL_INIT_SIZE);
	    config.setMaximumPoolSize(DataSourceConfig.POOL_MAX_ACTIVE);
		config.setConnectionTimeout(DataSourceConfig.REQUEST_TIMEOUT);
	    config.setConnectionTestQuery("select 1 from dual");
		config.setAutoCommit(false);
		
	   	HikariDataSource  datasource=new HikariDataSource(config);
		return datasource;
	}
}
