package test.type;
import com.alibaba.druid.pool.DruidDataSource;
import test.DataSourceConfig;

/**
 * product from Chinese alibaba
 */
public class Druid {
	public static DruidDataSource createDataSource() throws Exception {
		DruidDataSource datasource = new DruidDataSource();
		datasource.setUrl(DataSourceConfig.JDBC_URL);
		datasource.setUsername(DataSourceConfig.JDBC_USER);
		datasource.setPassword(DataSourceConfig.JDBC_PASSWORD);
		datasource.setDriverClassName(DataSourceConfig.JDBC_DRIVER);

		datasource.setMaxActive(DataSourceConfig.POOL_MAX_ACTIVE);
		datasource.setMinIdle(DataSourceConfig.POOL_MIN_ACTIVE);
		datasource.setInitialSize(DataSourceConfig.POOL_INIT_SIZE);
		datasource.setPoolPreparedStatements(true);
		datasource.setMaxPoolPreparedStatementPerConnectionSize(20);
//		datasource.setMinEvictableIdleTimeMillis(3000000);
//		datasource.setMaxWaitThreadCount(1000000);
        datasource.setMaxWait(DataSourceConfig.REQUEST_TIMEOUT);
		datasource.setValidationQuery("select 1 from dual");

		datasource.setTestOnBorrow(true);
		datasource.setTestOnReturn(false);
		datasource.setUseUnfairLock(true);
		datasource.setDefaultAutoCommit(false);
		return datasource;
	}
}
