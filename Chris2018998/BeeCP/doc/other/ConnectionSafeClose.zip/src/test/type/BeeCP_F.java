package test.type;

import cn.beecp.BeeDataSource;
import cn.beecp.BeeDataSourceConfig;
import test.DataSourceConfig;

/**
 * fair mode for BeeCP
 * 
 */
public class BeeCP_F {

	public static BeeDataSource createDataSource() throws Exception{
		BeeDataSourceConfig config = new BeeDataSourceConfig();
		config.setDriverClassName(DataSourceConfig.JDBC_DRIVER);
		config.setJdbcUrl(DataSourceConfig.JDBC_URL);
		config.setUsername(DataSourceConfig.JDBC_USER);
		config.setPassword(DataSourceConfig.JDBC_PASSWORD);
		config.setMaxActive(DataSourceConfig.POOL_MAX_ACTIVE);
		config.setInitialSize(DataSourceConfig.POOL_INIT_SIZE);
		config.setMaxWait(DataSourceConfig.REQUEST_TIMEOUT);
 		config.setConnectionTestSQL("select 1 from dual");
		config.setDefaultAutoCommit(false);
		config.setFairMode(true);
		return new BeeDataSource(config);
	}  		 
}
