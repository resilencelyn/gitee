package test.type;

import org.apache.commons.dbcp2.BasicDataSource;
import test.DataSourceConfig;

/**
 * DBCP
 */
public class DBCP2{
	public static BasicDataSource createDataSource() throws Exception {
		BasicDataSource datasource = new BasicDataSource();
		datasource.setUrl(DataSourceConfig.JDBC_URL);
		datasource.setDriverClassName(DataSourceConfig.JDBC_DRIVER);
		datasource.setUsername(DataSourceConfig.JDBC_USER);
		datasource.setPassword(DataSourceConfig.JDBC_PASSWORD);
		
		datasource.setInitialSize(DataSourceConfig.POOL_INIT_SIZE);
		datasource.setMinIdle(DataSourceConfig.POOL_MIN_ACTIVE);
		datasource.setMaxIdle(DataSourceConfig.POOL_MIN_ACTIVE);
		datasource.setMaxTotal(DataSourceConfig.POOL_MAX_ACTIVE);
		datasource.setMaxWaitMillis(DataSourceConfig.REQUEST_TIMEOUT);
		datasource.setPoolPreparedStatements(true);
		datasource.setMaxOpenPreparedStatements(20);
		datasource.setValidationQuery("select 1 from dual");

		datasource.setTestOnBorrow(true);
		datasource.setTestOnReturn(false);
		datasource.setDefaultAutoCommit(false);
		return datasource;
	}
}
